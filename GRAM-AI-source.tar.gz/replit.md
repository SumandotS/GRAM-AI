# GRAM-AI

GRAM-AI is a safety-first clinical decision-support prototype for ASHA and community health workers. It structures an assessment, checks configured danger signs deterministically, keeps uncertainty visible, and prepares a printable referral handoff.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/gram-ai run dev` — run the web app
- `pnpm run typecheck` — full workspace typecheck
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API client and Zod schemas from the OpenAPI contract

## Stack

- React + Vite frontend
- Express API server
- OpenAPI-first contracts with Orval-generated React Query hooks and Zod schemas
- In-memory assessment sessions for the demo (patient data is not persisted)
- Deterministic red-flag rules
- Ollama reachability detection for LOCAL/DEMO status

## Where things live

- `lib/api-spec/openapi.yaml` — API source of truth
- `artifacts/api-server/src/routes/` — API routes
- `artifacts/api-server/src/lib/safety.ts` — deterministic danger-sign rules
- `artifacts/api-server/src/lib/assessment-store.ts` — short-lived demo session state
- `artifacts/gram-ai/src/pages/` — user-facing assessment, result, referral, evidence, evaluation, and status screens

## Architecture decisions

- Safety checks run independently of model availability and take priority over normal triage.
- The app reports DEMO mode when Ollama is not reachable; it never presents the mock path as Phi-3 Mini.
- Missing knowledge-base documents and evaluation metrics are shown as unavailable, not replaced by fabricated evidence or results.
- Assessment session data is held in memory on the API and in session storage in the browser for this prototype; production use requires an approved privacy and retention design.

## Product

The current build supports a worker-led assessment flow, structured intake, targeted clarification, red-flag review, triage display, evidence availability messaging, referral-note preparation, evaluation status, and runtime status.

## Gotchas

- This is a prototype and not a medical device or a diagnosis tool.
- A patient who appears severely unwell should be referred immediately using local emergency protocol, even if the app is unavailable.
- No clinical knowledge-base PDF or training dataset was supplied to this project, so RAG, Random Forest, and measured evaluation remain explicitly unavailable.