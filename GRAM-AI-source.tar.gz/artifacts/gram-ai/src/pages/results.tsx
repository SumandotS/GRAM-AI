import { ArrowRight, BookOpen, CircleAlert, ExternalLink, FileText, RefreshCw, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import type { AnalysisResult, Evidence, IntakeInput } from '@workspace/api-client-react';
import { useRetrieveEvidence } from '@workspace/api-client-react';
import { Button, DataState, Panel } from '@/components/gram-shell';

function triageLabel(value?: string) { return value?.replaceAll('_', ' ') ?? 'Not available'; }
function triageTone(value?: string) { return value === 'urgent_referral' ? 'border-destructive/30 bg-destructive/5 text-destructive' : value === 'routine_referral' ? 'border-accent/40 bg-accent/10 text-foreground' : 'border-primary/25 bg-secondary text-primary'; }

export default function Results() {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [intake, setIntake] = useState<Partial<IntakeInput> | null>(null);
  const evidence = useRetrieveEvidence();
  useEffect(() => {
    try {
      const stored = sessionStorage.getItem('gram-current-result');
      const storedIntake = sessionStorage.getItem('gram-current-intake');
      if (stored) setResult(JSON.parse(stored));
      if (storedIntake) setIntake(JSON.parse(storedIntake));
    } catch { setResult(null); }
  }, []);
  const findEvidence = () => {
    const query = [intake?.chiefComplaint, ...(intake?.symptoms ?? [])].filter(Boolean).join('. ');
    if (query) evidence.mutate({ data: { query, limit: 5 } });
  };
  return (
    <div className="mx-auto max-w-[1200px] px-5 py-8 md:px-10 md:py-12">
      <div className="mb-9 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="font-mono-app text-[10px] uppercase tracking-[0.16em] text-primary">Current assessment</p><h1 className="mt-2 font-serif-app text-4xl tracking-tight md:text-5xl">A result you can explain</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Review the suggested triage with the patient’s story, danger signs, evidence, and uncertainty all in view.</p></div>{result && <Link href="/referral" className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg border border-border bg-card px-4 text-sm font-semibold text-foreground hover:bg-muted" data-testid="link-create-referral"><FileText size={16} /> Prepare referral note</Link>}</div>
      <DataState empty={!result}>Complete an assessment to see triage, possible conditions, and the evidence used. Nothing is inferred when a session is missing.</DataState>
      {result && <div className="space-y-5">
        <Panel className={`border p-6 md:p-8 ${triageTone(result.triage)}`}><div className="flex flex-col justify-between gap-5 md:flex-row md:items-start"><div><div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em]"><ShieldCheck size={16} /> Suggested triage</div><h2 className="mt-4 font-serif-app text-4xl capitalize tracking-tight" data-testid="text-triage">{triageLabel(result.triage)}</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-foreground/75" data-testid="text-triage-reason">{result.triageReason}</p></div><span className="rounded-full border border-current/20 px-3 py-1.5 font-mono-app text-[10px] uppercase tracking-[0.12em]">{result.modelMode} mode</span></div></Panel>
        <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
          <Panel className="p-6"><div className="flex items-center justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Clinical picture</p><h2 className="mt-2 font-serif-app text-2xl">Possible conditions</h2></div><span className="text-xs text-muted-foreground">{result.possibleConditions.length} recorded</span></div><div className="mt-6 divide-y divide-border">{result.possibleConditions.length ? result.possibleConditions.map((condition, index) => <div className="flex gap-4 py-4 first:pt-0 last:pb-0" key={`${condition.name}-${index}`}><div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-secondary font-mono-app text-xs text-primary">{index + 1}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-baseline justify-between gap-2"><h3 className="font-semibold">{condition.name}</h3><span className="font-mono-app text-xs text-primary">{Math.round(condition.probability * 100)}% signal</span></div><p className="mt-1 text-sm leading-6 text-muted-foreground">{condition.basis}</p></div></div>) : <p className="text-sm text-muted-foreground">No possible conditions were returned.</p>}</div></Panel>
          <div className="space-y-5"><Panel className="p-6"><div className="flex items-center gap-2 text-sm font-semibold"><CircleAlert size={17} className={result.redFlags.length ? 'text-destructive' : 'text-primary'} /> Danger signs</div>{result.redFlags.length ? <div className="mt-4 space-y-3">{result.redFlags.map((flag) => <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-3" key={flag.id}><p className="text-sm font-semibold text-destructive">{flag.label}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{flag.reason}</p><p className="mt-2 text-xs font-semibold text-foreground">{flag.action}</p></div>)}</div> : <p className="mt-3 text-sm leading-6 text-muted-foreground">No configured danger signs were returned. This does not rule out serious illness.</p>}</Panel><Panel className="p-6"><p className="font-mono-app text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Uncertainty</p><p className="mt-3 text-sm leading-6 text-foreground" data-testid="text-uncertainty">{result.uncertainty || 'No uncertainty statement was returned.'}</p></Panel></div>
        </div>
        <Panel className="p-6 md:p-8"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="flex items-center gap-2 text-sm font-semibold"><BookOpen size={17} className="text-primary" /> Visible evidence</div><p className="mt-1 text-sm text-muted-foreground">Passages should be checked against the source and your local protocol.</p></div><Button variant="secondary" onClick={findEvidence} disabled={evidence.isPending} data-testid="button-refresh-evidence">{evidence.isPending ? <RefreshCw className="animate-spin" size={15} /> : <RefreshCw size={15} />} Retrieve evidence</Button></div><div className="mt-6"><DataState loading={evidence.isPending} error={evidence.isError} empty={!result.evidence.length && !evidence.data?.evidence?.length} retry={findEvidence}>No evidence was attached to this result. Retrieve the relevant local passages when the knowledge base is available.</DataState>{(result.evidence.length ? result.evidence : evidence.data?.evidence ?? []).map((item: Evidence, index) => <div className="border-t border-border py-5 first:border-t-0" key={`${item.source}-${item.page}-${index}`}><div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground"><span className="font-semibold text-foreground">{item.source}</span><span>Page {item.page}</span><span>{item.section}</span><ExternalLink size={13} /></div><blockquote className="mt-2 border-l-2 border-accent pl-3 font-serif-app text-[17px] leading-7 text-foreground/85">“{item.passage}”</blockquote></div>)}</div></Panel>
        <div className="rounded-xl border border-accent/30 bg-accent/10 p-5"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-foreground">Clinical disclaimer</p><p className="mt-2 text-sm leading-6 text-foreground/75" data-testid="text-disclaimer">{result.disclaimer}</p></div>
        <div className="flex justify-end"><Link href="/assessment" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline" data-testid="link-new-assessment">Start another assessment <ArrowRight size={16} /></Link></div>
      </div>}
    </div>
  );
}