import { ArrowRight, CheckCircle2, CircleAlert, Clock3, Database, ShieldCheck, Stethoscope } from 'lucide-react';
import { Link } from 'wouter';
import { useGetSystemStatus } from '@workspace/api-client-react';
import { Button, DataState, Panel } from '@/components/gram-shell';

export default function Home() {
  const status = useGetSystemStatus();
  const system = status.data;
  const mode = system?.mode ?? '—';
  return (
    <div className="mx-auto max-w-[1320px] px-5 py-10 md:px-10 md:py-14">
      <div className="grid gap-10 lg:grid-cols-[1.15fr_.85fr] lg:items-end">
        <div>
          <div className="mb-7 flex items-center gap-2 text-xs font-semibold text-primary"><span className="grid h-7 w-7 place-items-center rounded-full bg-secondary"><ShieldCheck size={15} /></span> A quiet second set of eyes for the field</div>
          <h1 className="max-w-3xl font-serif-app text-[52px] leading-[.98] tracking-[-0.05em] text-foreground md:text-[76px]">Good decisions start with <em className="text-primary">good questions.</em></h1>
          <p className="mt-7 max-w-xl text-[17px] leading-8 text-muted-foreground">GRAM-AI helps ASHA and community health workers structure an assessment, check for danger signs, and prepare the next safe step. It keeps uncertainty visible.</p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/assessment" className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-105" data-testid="link-start-assessment">Start an assessment <ArrowRight size={17} /></Link>
            <Link href="/system-status" className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-border bg-card px-5 text-sm font-semibold text-foreground transition hover:bg-muted" data-testid="link-view-system-status">View system status</Link>
          </div>
        </div>
        <div className="relative overflow-hidden rounded-[26px] border border-border bg-secondary p-6 md:p-8">
          <div className="absolute -right-12 -top-16 h-48 w-48 rounded-full border-[18px] border-accent/20" />
          <div className="absolute -bottom-20 -left-12 h-48 w-48 rounded-full border-[1px] border-primary/20" />
          <div className="relative">
            <p className="font-mono-app text-[10px] uppercase tracking-[0.16em] text-primary">How it works</p>
            <div className="mt-7 space-y-5">
              {[['01', 'Listen first', 'Capture what the patient says, in the worker’s own words.'], ['02', 'Check the edges', 'Surface danger signs and ask only the clarifying questions that matter.'], ['03', 'Make the next step clear', 'A triage suggestion with evidence, uncertainty, and a referral note.']].map(([number, title, body]) => <div className="flex gap-4" key={number}><span className="font-mono-app text-xs text-primary/70">{number}</span><div><h3 className="font-semibold text-foreground">{title}</h3><p className="mt-1 text-sm leading-6 text-muted-foreground">{body}</p></div></div>)}
            </div>
          </div>
        </div>
      </div>
      <div className="mt-20 grid gap-4 md:grid-cols-3">
        {[{ icon: Stethoscope, title: 'Built for the visit', text: 'Short steps, plain language, and a clear handoff when the case needs a facility.' }, { icon: CircleAlert, title: 'Safety before certainty', text: 'Red flags are checked before an analysis is shown. Missing information stays visible.' }, { icon: Database, title: 'Evidence on the page', text: 'When the knowledge base is available, passages and source locations are shown alongside the reasoning.' }].map(({ icon: Icon, title, text }) => <Panel key={title} className="p-5"><Icon className="text-primary" size={21} /><h2 className="mt-5 font-serif-app text-2xl">{title}</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">{text}</p></Panel>)}
      </div>
      <div className="mt-10 grid gap-4 lg:grid-cols-[1fr_1.6fr]">
        <Panel className="p-6">
          <p className="font-mono-app text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Before you begin</p>
          <h2 className="mt-4 font-serif-app text-2xl">A support tool, not a diagnosis</h2>
          <p className="mt-3 text-sm leading-6 text-muted-foreground">Use your clinical training and local protocols. Escalate immediately when a patient appears seriously unwell, even if this tool is unavailable.</p>
        </Panel>
        <Panel className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-border px-6 py-4"><div><p className="font-mono-app text-[10px] uppercase tracking-[0.16em] text-muted-foreground">System snapshot</p><p className="mt-1 text-sm font-semibold text-foreground">Ready for a local assessment</p></div><span className="rounded-full bg-secondary px-2.5 py-1 font-mono-app text-[10px] text-primary">{mode} mode</span></div>
          <DataState loading={status.isLoading} error={status.isError} retry={() => status.refetch()}><div className="grid grid-cols-2 divide-x divide-border md:grid-cols-4">{[['Backend', system?.backend], ['Reasoning', system?.langgraph], ['Evidence', system?.knowledgeBase], ['Model', system?.phi3Mini]].map(([label, value]) => <div className="p-5" key={label}><div className="flex items-center gap-2 text-xs text-muted-foreground"><CheckCircle2 size={14} className={value && !String(value).includes('not_') && value !== 'disconnected' && value !== 'unavailable' ? 'text-primary' : 'text-muted-foreground'} />{label}</div><p className="mt-2 truncate font-mono-app text-xs uppercase text-foreground">{value?.replaceAll('_', ' ') ?? '—'}</p></div>)}</div></DataState>
        </Panel>
      </div>
      <footer className="mt-16 flex flex-col gap-2 border-t border-border pt-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between"><span>GRAM-AI / Safety-first clinical decision support</span><span className="flex items-center gap-2"><Clock3 size={13} /> Designed for thoughtful, local care</span></footer>
    </div>
  );
}