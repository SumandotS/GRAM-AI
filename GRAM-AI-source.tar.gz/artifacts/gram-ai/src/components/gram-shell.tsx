import { Activity, ClipboardList, FileText, FlaskConical, Home, Library, Menu, Network, ShieldCheck, X } from 'lucide-react';
import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useGetSystemStatus, useHealthCheck } from '@workspace/api-client-react';

const nav = [
  { href: '/', label: 'Overview', icon: Home },
  { href: '/assessment', label: 'New assessment', icon: ClipboardList },
  { href: '/results', label: 'Assessment result', icon: Activity },
  { href: '/referral', label: 'Referral note', icon: FileText },
  { href: '/knowledge-base', label: 'Knowledge base', icon: Library },
  { href: '/evaluation', label: 'Evaluation', icon: FlaskConical },
  { href: '/system-status', label: 'System status', icon: Network },
];

function StatusPill() {
  const { data: health, isLoading } = useHealthCheck();
  const { data: system } = useGetSystemStatus();
  const online = health?.status === 'ok' || health?.status === 'healthy';
  return (
    <div className="flex items-center gap-2 text-xs text-sidebar-foreground/70" data-testid="status-api-health">
      <span className={`h-2 w-2 rounded-full ${isLoading ? 'bg-sidebar-foreground/40 animate-pulse' : online ? 'bg-emerald-300' : 'bg-amber-300'}`} />
      {isLoading ? 'Checking service' : online ? `${system?.mode ?? 'Service'} mode` : 'Service status unknown'}
    </div>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-[100dvh] bg-background md:flex">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[266px] flex-col bg-sidebar px-4 py-5 text-sidebar-foreground shadow-xl transition-transform duration-200 md:relative md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-start justify-between px-3">
          <Link href="/" className="group" onClick={() => setOpen(false)} data-testid="link-brand">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-[14px] bg-sidebar-primary text-sidebar-primary-foreground shadow-sm">
                <ShieldCheck size={22} strokeWidth={2.2} />
              </span>
              <div>
                <div className="font-serif-app text-[21px] leading-none tracking-tight">GRAM-AI</div>
                <div className="mt-1 font-mono-app text-[9px] uppercase tracking-[0.16em] text-sidebar-foreground/55">field decision support</div>
              </div>
            </div>
          </Link>
          <button className="mt-1 rounded-md p-1 text-sidebar-foreground/60 hover:bg-sidebar-accent md:hidden" onClick={() => setOpen(false)} data-testid="button-close-menu" aria-label="Close menu"><X size={18} /></button>
        </div>
        <div className="mx-3 mt-8 border-t border-sidebar-border pt-5">
          <p className="px-3 pb-2 font-mono-app text-[10px] uppercase tracking-[0.14em] text-sidebar-foreground/45">Workspace</p>
          <nav className="space-y-1">
            {nav.map(({ href, label, icon: Icon }) => {
              const active = href === '/' ? location === '/' : location.startsWith(href);
              return (
                <Link key={href} href={href} onClick={() => setOpen(false)} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors ${active ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/68 hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground'}`}>
                  <Icon size={17} strokeWidth={active ? 2.2 : 1.8} />
                  <span>{label}</span>
                  {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto rounded-xl border border-sidebar-border bg-sidebar-accent/45 p-3">
          <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold text-sidebar-foreground/85"><span className="h-1.5 w-1.5 rounded-full bg-sidebar-primary" /> Safety-first mode</div>
          <p className="text-[11px] leading-relaxed text-sidebar-foreground/55">GRAM-AI supports clinical judgment. It never replaces a trained health worker.</p>
          <div className="mt-4"><StatusPill /></div>
        </div>
      </aside>
      {open && <button className="fixed inset-0 z-30 bg-foreground/20 md:hidden" onClick={() => setOpen(false)} aria-label="Close navigation overlay" data-testid="button-overlay-close" />}
      <main className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border/80 bg-background/90 px-5 backdrop-blur md:px-10">
          <button className="rounded-lg border border-border p-2 text-foreground/70 md:hidden" onClick={() => setOpen(true)} aria-label="Open navigation" data-testid="button-open-menu"><Menu size={19} /></button>
          <div className="hidden font-mono-app text-[10px] uppercase tracking-[0.16em] text-muted-foreground md:block">Community health workspace / 01</div>
          <div className="ml-auto flex items-center gap-3">
            <Link href="/system-status" className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground" data-testid="link-header-system-status"><span className="h-2 w-2 rounded-full bg-emerald-600" /> Runtime status</Link>
          </div>
        </header>
        <div className="animate-rise-in">{children}</div>
      </main>
    </div>
  );
}

export function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-9 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
      <div>
        <p className="mb-3 font-mono-app text-[10px] uppercase tracking-[0.17em] text-primary">{eyebrow}</p>
        <h1 className="max-w-3xl font-serif-app text-4xl leading-[1.08] tracking-[-0.035em] text-foreground md:text-[48px]">{title}</h1>
        {description && <p className="mt-4 max-w-2xl text-[15px] leading-7 text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function Button({ children, variant = 'primary', className = '', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'quiet' | 'danger' }) {
  const variants = {
    primary: 'bg-primary text-primary-foreground hover:brightness-105 shadow-sm',
    secondary: 'border border-border bg-card text-foreground hover:bg-muted',
    quiet: 'text-muted-foreground hover:bg-muted hover:text-foreground',
    danger: 'bg-destructive text-destructive-foreground hover:brightness-105',
  };
  return <button {...props} className={`inline-flex min-h-10 items-center justify-center gap-2 rounded-lg px-4 text-sm font-semibold transition-all duration-150 disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant]} ${className}`} />;
}

export function Panel({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <section className={`rounded-2xl border border-card-border bg-card shadow-sm ${className}`}>{children}</section>;
}

export function DataState({ loading, error, empty, children, retry }: { loading?: boolean; error?: boolean; empty?: boolean; children: React.ReactNode; retry?: () => void }) {
  if (loading) return <div className="space-y-3" data-testid="state-loading"><div className="h-20 animate-pulse rounded-xl bg-muted" /><div className="h-28 animate-pulse rounded-xl bg-muted" /></div>;
  if (error) return <div className="rounded-xl border border-destructive/25 bg-destructive/5 p-6 text-sm text-destructive" data-testid="state-error"><p className="font-semibold">This information is unavailable right now.</p><p className="mt-1 text-destructive/80">Check the service connection and try again.</p>{retry && <Button variant="secondary" className="mt-4" onClick={retry} data-testid="button-retry">Retry</Button>}</div>;
  if (empty) return <div className="rounded-xl border border-dashed border-border bg-muted/40 p-8 text-center" data-testid="state-empty"><p className="font-serif-app text-xl text-foreground">Nothing has been recorded yet</p><p className="mt-2 text-sm leading-6 text-muted-foreground">{children}</p></div>;
  return <>{children}</>;
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return <label className="block"><span className="mb-2 block text-sm font-semibold text-foreground">{label}</span>{children}{hint && <span className="mt-1.5 block text-xs text-muted-foreground">{hint}</span>}</label>;
}

export const inputClass = 'w-full rounded-lg border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/15';
